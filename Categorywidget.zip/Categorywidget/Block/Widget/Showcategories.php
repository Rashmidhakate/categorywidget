<?php 
namespace Custom\Categorywidget\Block\Widget;

use Magento\Framework\View\Element\Template;
use Magento\Widget\Block\BlockInterface; 
use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory;
use Magento\Framework\View\Element\Template\Context;
use Magento\Store\Model\StoreManagerInterface;
 
class Showcategories extends Template implements BlockInterface {

	protected $_template = "widget/showcategories.phtml";
	protected $categoryRepository;
    protected $_categoryCollectionFactory;
    protected $_storeManager;
    protected $_filesystem ;
    protected $_imageFactory;

    public function __construct(Context $context, 
        StoreManagerInterface $storeManager,
        \Magento\Framework\Filesystem $filesystem,         
        \Magento\Framework\Image\AdapterFactory $imageFactory,
         CollectionFactory $categoryCollectionFactory)
    {
 
        $this->_storeManager = $storeManager;
        $this->_categoryCollectionFactory = $categoryCollectionFactory;
        $this->_filesystem = $filesystem;               
        $this->_imageFactory = $imageFactory;         
        parent::__construct($context);
    }

    
    public function getCategoryIds()
    {
        if ($this->hasData('categoryids')) {
            return $this->getData('categoryids');
        }
        return $this->getData('categoryids');
    }

    public function getCategoryCollection()
    {
        $category_ids = explode(",", $this->getCategoryIds());
        $condition = ['in' => array_values($category_ids)];
 
        $collection = $this->_categoryCollectionFactory->create()->addAttributeToFilter('entity_id', $condition)->addAttributeToSelect(['name', 'is_active', 'parent_id', 'image','position'])->setStoreId($this->_storeManager->getStore()->getId());
        return $collection;
    }
 

}
